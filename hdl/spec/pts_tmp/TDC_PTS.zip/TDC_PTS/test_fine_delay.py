#!   /usr/bin/env   python
#    coding: utf8

# Copyright CERN, 2011
# Author: Matthieu Cattin <matthieu.cattin@cern.ch>
# Licence: GPL v2 or later.
# Website: http://www.ohwr.org

# Import system modules
import sys
import time
import os
import math

# Add common modules location tp path
sys.path.append('../../../')
sys.path.append('../../../gnurabbit/python/')
sys.path.append('../../../common/')

# Import common modules
from ptsexcept import *
import rr

# Import specific modules
import fmc_tdc
sys.path.append('../../../../fmc_delay/software/python/')
import fdelay_lib


"""
test00: Load firmware and test mezzanine presence line.
"""
def main (default_directory='.'):

    # Constants declaration

    FMC_TDC_ADDR = '1a39:0004/1a39:0004@000B:0000'
    FMC_TDC_BITSTREAM = '../firmwares/evas_tdc_irq5.bit'
    FMC_TDC_CHANNEL_NB = 5
    
    FMC_DELAY_ADDR = '1a39:0004/1a39:0004@0005:0000'
    FMC_DELAY_BITSTREAM = '../firmwares/fmc_delay_spec.bin'

    # SPEC object declaration
    spec = rr.Gennum()


    ###########################################################################
    # Fine Delay
    ###########################################################################
    print "\n-----------------------------------------------------------------"
    print "------------------------- FMC FINE DELAY ------------------------"
    print "\n--  --  --  --  --  --  --  --  --  --  --  --  --  --  --"
    # Bind SPEC object to FMC Fine Delay card
    print "\nFine Delay address to parse: %s"%(FMC_DELAY_ADDR)
    for name, value in spec.parse_addr(FMC_DELAY_ADDR).iteritems():
        print "%9s:0x%04X"%(name, value)
    spec.bind(FMC_DELAY_ADDR)

    # Load FMC Fine Delay firmware
    print "\nLoading FMC Fine Delay firmware..."
    spec.load_firmware(FMC_DELAY_BITSTREAM)
    time.sleep(2)
    print "\nFMC Fine Delay firmware loaded!"

    # Fine Delay object declaration
    print "\n"
    fdelay = fdelay_lib.FineDelay(spec.get_fd())

    # Set UTC and Coarse time in the Fine Delay
    fdelay.set_time(0, 0)
    fd_time = fdelay_lib.fd_timestamp()
    fd_time = fdelay.get_time()
    print "\nFine Delay UTC time = %d, Coarse time = %d"%(fd_time.utc, fd_time.coarse)

    # Configure the Fine Delay as a pulse generator
    channel = 1 # must be 1, 2, 3 or 4
    enable = 1 # this one is obvious
    t_start_utc = fdelay.get_time().utc+1 # pulse(s) generation start time (-> 2 seconds in the future)
    t_start_coarse = 0
    width = 250000000000 # 0.25 sec # 50000    # pulse width 50 ns
    delta = 500000000000 # 0.5sec  # 100000   # a pulse every 100 ns
    count = -1 # 0:infinite repetition
    
    fdelay.conf_pulsegen(channel, enable, t_start_utc, t_start_coarse, width, delta, count)
    fdelay.conf_pulsegen(channel+1, enable, t_start_utc, t_start_coarse+50, width, delta, count)

    

if __name__ == '__main__' :
    main()
