#!   /usr/bin/env   python
#    coding: utf8

# Copyright CERN, 2011
# Author: Matthieu Cattin <matthieu.cattin@cern.ch>
# Licence: GPL v2 or later.
# Website: http://www.ohwr.org


####### n=0; while [[ $n -lt 10 ]]; do echo Iteration $n; sudo ./test05_v2.py; n=$((n+1)); done | tee -a tmp.txt  #######

# Import system modules
import sys
import time
import os
import math
import pylab
from pylab import *


# Add common modules location tp path
sys.path.append('../../../')
sys.path.append('../../../gnurabbit/python/')
sys.path.append('../../../common/')

# Import common modules
from ptsexcept import *
import rr

# Import specific modules
import fmc_tdc
sys.path.append('../../../../fmc_delay/software/python/')
import fdelay_lib


"""
test_cesium: Tests with cesium clock pps as input
"""

def main (default_directory='.'):

    # Constants declaration
    FMC_TDC_ADDR = '1a39:0004/1a39:0004@000B:0000'
    FMC_TDC_BITSTREAM = '../firmwares/evas_tdc_v2_2.bit'#evas_tdc_leds.bit'#evas_tdc_pll_status2.bit'#evas_tdc_ctrl_dac.bit#evas_tdc_irq8.bit'
    FMC_TDC_CHANNEL_NB = 5
    
    FMC_DELAY_ADDR = '1a39:0004/1a39:0004@0005:0000'
    FMC_DELAY_BITSTREAM = '../firmwares/fmc_delay_spec.bin'

    # SPEC object declaration
    spec = rr.Gennum()


    ###########################################################################
    # TDC
    ###########################################################################

    # Bind SPEC object to FMC TDC card
    print "-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    print "\n_______________________________Info______________________________\n"
    print "FMC TDC address to parse: %s"%(FMC_TDC_ADDR)
    for name, value in spec.parse_addr(FMC_TDC_ADDR).iteritems():
        print "%s:0x%04X"%(name, value)
    spec.bind(FMC_TDC_ADDR)

    # Load FMC TDC firmware
    print "\n_________________________Initialisations_________________________\n"
    print "Loading FMC TDC firmware...",
    spec.load_firmware(FMC_TDC_BITSTREAM)
    time.sleep(2)
    print "Firmware loaded!"

    # TDC object declaration
    tdc = fmc_tdc.CFMCTDC(spec)

    # TDC configuration
    print "\n__________________________Configuration__________________________\n"
    tdc.config_acam()
    tdc.set_irq_tstamp_thresh(0x100) # set to 
    tdc.set_irq_time_thresh(0x89)   #  secs
    time.sleep(1)

    # Enable TDC core interrupts
    print "\n____________________________IRQ mask_____________________________\n"
    print('Set IRQ enable mask: %.4X')%tdc.set_irq_en_mask(0xC)


    # Check ACAM status
    print "\n___________________________ACAM reset____________________________\n"
    tdc.reset_acam()
    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "


    # Readback all ACAM configuration regs
    print "\n_________________Reading back ACAM configuration_________________\n"
    tdc.readback_acam_config()


    # Configuring DAC and PLL again
    print "\n_____________________Configuring DAC and PLL_____________________\n"
    tdc.configure_mezz_dac(0xAA57) # nominal: xAA57, max: xFFFF, min: x0000

    time.sleep(2)

    # Enable timestamps aquisition
    print "\n_______________________Starting aquisition_______________________\n"
    # Enable channels
    tdc.enable_channels()
    for ch in range(1,FMC_TDC_CHANNEL_NB+1):
        tdc.channel_term(ch, 1)

    tdc.start_acq()


    all_periods_min = []
    all_periods_max = []
    all_driftfrom1sec_min = []
    all_driftfrom1sec_max = []
    time_list = []


    print "\n________________________Accuracy testing_________________________\n"

    # several iterations of getting pulses from the cesium clock and retrieving timestamps 
    for m in range(3):

        tdc.check_irq(0)

        if (tdc.get_pointer() != 0) or (tdc.get_overflow_counter() != m+1):
            print "\n\nIRQ iteration: %d // Overflows: %d // IRQ source: %d // Write pointer: %d \r"%(m, tdc.get_overflow_counter(), tdc.get_irq_src(), tdc.get_pointer()),

        tdc.clear_irq_src(int(math.log(tdc.get_irq_src(),2)))


        timestamps, data = tdc.get_timestamps(0)


        if (tdc.get_pointer() != 0) or (tdc.get_overflow_counter() != m+1):
            print "IRQ iteration: %d // Overflows: %d // IRQ source: %d // Write pointer: %d \r"%(m, tdc.get_overflow_counter(), tdc.get_irq_src(), tdc.get_pointer()),

        r_edge_timestamps = []
        period_list = []
        driftfrom1sec_list = []

        for i in range(len(timestamps)):
             if ((timestamps[i][2] == 1)): #and (timestamps[i][1] == 4)):
                 r_edge_timestamps.append(timestamps[i][0])

        if m == 0:
            del r_edge_timestamps[0]

        for i in range(0,len(r_edge_timestamps)-1):
            period = r_edge_timestamps[i+1] - r_edge_timestamps[i]
            period_list.append(period)

        for i in range(0,len(period_list)):
            driftfrom1sec = 1e12 - period_list[i]
            driftfrom1sec_list.append(driftfrom1sec)

        current_max = max(period_list)
        current_min = min(period_list)

        driftfrom1sec_current_max = max(driftfrom1sec_list)
        driftfrom1sec_current_min = min(driftfrom1sec_list)

        print "\n__________________Iteration %d Accuracy Results_________________\n"%m


        current_time = int(round(time.time() * 1000))
        print "Time: %d"%current_time
        time_list.append(current_time)

        #print "Number of timestamps            : %d"%(len(timestamps))
        #print "Number of rising edges          : %d"%(len(r_edge_timestamps))
        print "Max  of this iteration         : %15.3f ps"%max(period_list)
        print "Min  of this iteration         : %15.3f ps"%min(period_list)
        #print "Span of this iteration         : %15.3f ps"%span


        all_periods_max.append(current_max)
        all_periods_min.append(current_min)

        all_driftfrom1sec_max.append(driftfrom1sec_current_max)
        all_driftfrom1sec_min.append(driftfrom1sec_current_min)

        print "Max so far found at iteration %d: %15.3f ps"%(all_periods_max.index(max(all_periods_max)), max(all_periods_max))
        print "Min so far found at iteration %d: %15.3f ps"%(all_periods_min.index(min(all_periods_min)), min(all_periods_min))
        print "Span so far                     : %15.3f ps"%((max(all_periods_max))-(min(all_periods_min)))

        print "Max 1sec drift so far found at iteration %d: %15.3f ps"%(all_driftfrom1sec_max.index(max(all_driftfrom1sec_max)), max(all_driftfrom1sec_max))
        print "Min 1sec drift so far found at iteration %d: %15.3f ps"%(all_driftfrom1sec_min.index(min(all_driftfrom1sec_min)), min(all_driftfrom1sec_min))


        if driftfrom1sec_current_max > 25000000 or driftfrom1sec_current_max < -25000000:
            print "\nDifferences from 1 sec"
            for i in range(0,len(driftfrom1sec_list)):
                print driftfrom1sec_list[i]
            print "\nRaw Timestamps"
            for i in range(len(data)):
                print data[i]
            print "\nRising edge Timestamps"
            for i in range(len(r_edge_timestamps)):
                print r_edge_timestamps[i]

        tdc.clear_irq_src(int(math.log(tdc.get_irq_src(),2)))


    # out of the for loop!
    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "

    print "\n_______________________Stopping aquisition_______________________\n"
    tdc.stop_acq()


    print "\n_______________________! Final Results !_________________________\n"
    #print all_periods_min
    #print all_periods_max
    #print "\n\nAnd the final max and min drift from 1 sec after %d pulses are %d and %d ps!\n"%((128*m), max(all_driftfrom1sec_max), min(all_driftfrom1sec_min))

    for i in range(len(time_list)):
        print time_list[i]


    print "\n-----------------------------------------------------------------\n\n\n"


if __name__ == '__main__' :
    main()
