#!   /usr/bin/env   python
#    coding: utf8

# Copyright CERN, 2011
# Author: Matthieu Cattin <matthieu.cattin@cern.ch>
# Licence: GPL v2 or later.
# Website: http://www.ohwr.org


####### n=0; while [[ $n -lt 10 ]]; do echo Iteration $n; sudo ./test05_v2.py; n=$((n+1)); done | tee -a tmp.txt  #######

# Import system modules
import sys
import time
import os
import math
import pylab
from pylab import *


# Add common modules location tp path
sys.path.append('../../../')
sys.path.append('../../../gnurabbit/python/')
sys.path.append('../../../common/')

# Import common modules
from ptsexcept import *
import rr

# Import specific modules
import fmc_tdc
sys.path.append('../../../../fmc_delay/software/python/')
import fdelay_lib


"""
test04: Test the write pointer and the interrupts occurence
"""
def main (default_directory='.'):

    # Constants declaration

    FMC_TDC_ADDR = '1a39:0004/1a39:0004@000B:0000'
    FMC_TDC_BITSTREAM = '../firmwares/evas_tdc_irq8.bit'
    FMC_TDC_CHANNEL_NB = 5
    
    FMC_DELAY_ADDR = '1a39:0004/1a39:0004@0005:0000'
    FMC_DELAY_BITSTREAM = '../firmwares/fmc_delay_spec.bin'

    # SPEC object declaration
    spec = rr.Gennum()


    ###########################################################################
    # TDC
    ###########################################################################

    # Bind SPEC object to FMC TDC card
    print "-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    print "\n_______________________________Info______________________________\n"
    print "FMC TDC address to parse: %s"%(FMC_TDC_ADDR)
    for name, value in spec.parse_addr(FMC_TDC_ADDR).iteritems():
        print "%s:0x%04X"%(name, value)
    spec.bind(FMC_TDC_ADDR)

    # Load FMC TDC firmware
    print "\n_________________________Initialisations_________________________\n"
    print "Loading FMC TDC firmware...",
    spec.load_firmware(FMC_TDC_BITSTREAM)
    time.sleep(2)
    print "Firmware loaded!"

    # TDC object declaration
    tdc = fmc_tdc.CFMCTDC(spec)

    # TDC configuration
    print "\n__________________________Configuration__________________________\n"
    tdc.config_acam()
    tdc.set_irq_tstamp_thresh(0xf0) # set to 240 tstamps
    tdc.set_irq_time_thresh(0x17)   # 23 secs
    time.sleep(1)

    tdc.enable_channels()
    for ch in range(1,FMC_TDC_CHANNEL_NB+1):
        tdc.channel_term(ch, 1)

    print "\n___________________________ACAM reset____________________________\n"
    tdc.reset_acam()
    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "


    ###########################################################################
    # Fine Delay
    ###########################################################################

    print "\n-----------------------------------------------------------------"
    print "------------------------- FMC FINE DELAY ------------------------"
    # Bind SPEC object to FMC Fine Delay card
    print "Fine Delay address to parse %s"%(FMC_DELAY_ADDR)
    for name, value in spec.parse_addr(FMC_DELAY_ADDR).iteritems():
        print "%s:0x%04X"%(name, value)
    spec.bind(FMC_DELAY_ADDR)

    # Load FMC Fine Delay firmware
    print "\n\nLoading FMC Fine Delay firmware...",
    sys.stdout.flush()
    spec.load_firmware(FMC_DELAY_BITSTREAM)
    time.sleep(2)
    print "Firmware loaded!"

    # Fine Delay object declaration
    print "\n"
    fdelay = fdelay_lib.FineDelay(spec.get_fd())

    # Set UTC and Coarse time in the Fine Delay
    fdelay.set_time(0, 0)
    fd_time = fdelay_lib.fd_timestamp()
    fd_time = fdelay.get_time()
    print "\nFine Delay UTC time = %d, Coarse time = %d"%(fd_time.utc, fd_time.coarse)

    # Configure the Fine Delay as a pulse generator
    channel = 1 # must be 1, 2, 3 or 4
    enable = 1 # this one is obvious
    t_start_utc = fdelay.get_time().utc+2 # pulse(s) generation start time (-> 2 seconds in the future)
    t_start_coarse = 0
    width = 2000000     # pulse width 2 us
    delta = 100000000   # a pulse every 100 us
    count = 60          # 60 pulses on each channel
    
    fdelay.conf_pulsegen(channel, enable, t_start_utc, t_start_coarse, width, delta, count)
    

    ###########################################################################
    # TDC
    ###########################################################################
    print "\n-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    # Bind SPEC object to FMC TDC card
    spec.bind(FMC_TDC_ADDR)

    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "

    print "\n_________________Reading back ACAM configuration_________________\n"
    tdc.readback_acam_config()

    # Enables TDC core interrupts
    print "\n____________________________IRQ mask_____________________________\n"
    print('Set IRQ enable mask: %.4X')%tdc.set_irq_en_mask(0xF)


    print "\n_______________________Starting aquisition_______________________\n"
    tdc.start_acq()

    print "\n________________________Accuracy testing_________________________\n"


    time.sleep(3)
    #tdc.check_irq()
    timestamps = tdc.get_timestamps(1)

    r_edge_timestamps = []
    cable_delay_list = []
    
    for i in range(len(timestamps)):
        if ((timestamps[i][2] == 1) and (timestamps[i][1] == 0 or timestamps[i][1] == 3)):
            r_edge_timestamps.append(timestamps[i][0])

    r_edge_timestamps.sort()



    for i in range(0,len(r_edge_timestamps),2):
        cable_delay = r_edge_timestamps[i+1] - r_edge_timestamps[i]
        cable_delay_list.append(cable_delay)
    """
        print "Cable length %2d: %15.3f ps"%(i/2, cable_delay)

    plot (cable_delay_list)
    show()
    """

    span = max(cable_delay_list)-min(cable_delay_list)
    print "Measuremtns span: %15.3f ps"%span
    print"max %d"%max(cable_delay_list)
    print"max %d"%min(cable_delay_list)


    if span > 800:
        print "Span messed up!"
        print"max %d"%max(cable_delay_list)
        print"max %d"%min(cable_delay_list)
    #    for i in range(len(timestamps)):
    #        print timestamps[i]


    print "\n_______________________Stopping aquisition_______________________\n"
    tdc.stop_acq()

    print "\n-----------------------------------------------------------------\n\n\n"


if __name__ == '__main__' :
    main()
