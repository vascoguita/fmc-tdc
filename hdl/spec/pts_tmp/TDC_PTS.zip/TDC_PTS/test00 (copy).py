#!   /usr/bin/env   python
#    coding: utf8

# Copyright CERN, 2011
# Author: Matthieu Cattin <matthieu.cattin@cern.ch>
# Licence: GPL v2 or later.
# Website: http://www.ohwr.org

# Import system modules
import sys
import time
import os

# Add common modules location tp path
sys.path.append('../../../')
sys.path.append('../../../gnurabbit/python/')
sys.path.append('../../../common/')

# Import common modules
from ptsexcept import *
import rr

# Import specific modules
import fmc_tdc
sys.path.append('../../../../fmc_delay/software/python/')
import fdelay_lib


"""
test00: Load firmware and test mezzanine presence line.
"""
def main (default_directory='.'):

    # Constants declaration

    FMC_TDC_ADDR = '1a39:0004/1a39:0004@000B:0000'
    FMC_TDC_BITSTREAM = '../firmwares/evas_tdc3.bit'
    FMC_TDC_CHANNEL_NB = 5
    
    FMC_DELAY_ADDR = '1a39:0004/1a39:0004@0005:0000'
    FMC_DELAY_BITSTREAM = '../firmwares/fmc_delay_spec.bin'

    # SPEC object declaration
    spec = rr.Gennum()

    ###########################################################################
    # TDC
    ###########################################################################

    # Bind SPEC object to FMC TDC card
    print "\n-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    print "\n--  --  --  --  --  --  --   -info-  --  --  --  --  --  --  --"
    print "FMC TDC address to parse: %s"%(FMC_TDC_ADDR)
    for name, value in spec.parse_addr(FMC_TDC_ADDR).iteritems():
        print "%9s:0x%04X"%(name, value)

    spec.bind(FMC_TDC_ADDR)

    # Load FMC TDC firmware
    print "\n--  --  --  --  --  --  initializations  --  --  --  --  --  --"
    print "Loading FMC TDC firmware"
    spec.load_firmware(FMC_TDC_BITSTREAM)
    time.sleep(2)

    # TDC object declaration
    tdc = fmc_tdc.CFMCTDC(spec)

    # TDC configuration
    tdc.config_acam()
    time.sleep(1)
    tdc.reset_acam()
    print "\n--  --  --  --  --  --  -acam status-  --  --  --  --  --  --"
    print "ACAM status:0x%08X"%tdc.read_acam_status()
    tdc.enable_channels()
    for ch in range(1,FMC_TDC_CHANNEL_NB+1):
        tdc.channel_term(ch, 1)

    ###########################################################################
    # Fine Delay
    ###########################################################################
    print "\n-----------------------------------------------------------------"
    print "------------------------- FMC FINE DELAY ------------------------"
    print "\n--  --  --  --  --  --  --  --  --  --  --  --  --  --  --"
    # Bind SPEC object to FMC Fine Delay card
    print "\nFine Delay address to parse: %s"%(FMC_DELAY_ADDR)
    for name, value in spec.parse_addr(FMC_DELAY_ADDR).iteritems():
        print "%9s:0x%04X"%(name, value)
    spec.bind(FMC_DELAY_ADDR)

    # Load FMC Fine Delay firmware
    print "\nLoading FMC Fine Delay firmware..."
    spec.load_firmware(FMC_DELAY_BITSTREAM)
    time.sleep(2)
    print "\nFMC Fine Delay firmware loaded!"

    # Fine Delay object declaration
    print "\n"
    fdelay = fdelay_lib.FineDelay(spec.get_fd())

    # Set UTC and Coarse time in the Fine Delay
    fdelay.set_time(0, 0)
    fd_time = fdelay_lib.fd_timestamp()
    fd_time = fdelay.get_time()
    print "\nFine Delay UTC time = %d, Coarse time = %d"%(fd_time.utc, fd_time.coarse)

    # Configure the Fine Delay as a pulse generator
    channel = 1 # must be 1, 2, 3 or 4
    enable = 1 # this one is obvious
    t_start_utc = fdelay.get_time().utc+4 # pulse(s) generation start time (-> 2 seconds in the future)
    t_start_coarse = 0
    width = 200000 # in [ps], must be > 200000
    delta = 1000000 # in [ps], must be > 200000
    count = 127 # infinite repetition
    fdelay.conf_pulsegen(channel, enable, t_start_utc, t_start_coarse, width, delta, count)
    fdelay.conf_pulsegen(channel+1, enable, t_start_utc, t_start_coarse+50, width, delta, count)

    ###########################################################################
    # TDC
    ###########################################################################
    print "\n-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    # Bind SPEC object to FMC TDC card
    spec.bind(FMC_TDC_ADDR)

    print "\n--  --  --  --  --  --  -acam status-  --  --  --  --  --  --"
    print "ACAM status:0x%08X"%tdc.read_acam_status()
    tdc.readback_acam_config()
    tdc.start_acq()
    
    for i in range(50):
        tdc_wr_ptr = tdc.get_pointer()
        tdc_overflow = tdc.get_overflow_counter()
        print "TDC buffer write pointer:0x%08X (%4d), overflow:%d"%(tdc_wr_ptr, tdc_wr_ptr, tdc_overflow)
        time.sleep(.1)

    timestamps = tdc.get_timestamps(1)

    for i in range(0,len(timestamps),2):
        width = timestamps[i+1][0] - timestamps[i][0]
        print "Pulse %2d width: %15.3f ps"%(i/2, width)
        if(i < (len(timestamps) - 2)):
            period = timestamps[i+2][0] - timestamps[i][0]
            print "period: %15.3f ps"%(period)


if __name__ == '__main__' :
    main()
