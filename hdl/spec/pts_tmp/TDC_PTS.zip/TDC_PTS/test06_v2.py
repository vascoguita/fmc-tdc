#!   /usr/bin/env   python
#    coding: utf8

# Copyright CERN, 2011
# Author: Matthieu Cattin <matthieu.cattin@cern.ch>
# Licence: GPL v2 or later.
# Website: http://www.ohwr.org


####### n=0; while [[ $n -lt 10 ]]; do echo Iteration $n; sudo ./test05_v2.py; n=$((n+1)); done | tee -a tmp.txt  #######

# Import system modules
import sys
import time
import os
import math
import pylab
from pylab import *


# Add common modules location tp path
sys.path.append('../../../')
sys.path.append('../../../gnurabbit/python/')
sys.path.append('../../../common/')

# Import common modules
from ptsexcept import *
import rr

# Import specific modules
import fmc_tdc
sys.path.append('../../../../fmc_delay/software/python/')
import fdelay_lib


"""
test06: Tests the TDC accuracy: pulses are sent in 2 different channels with some delay between them introduced through a cable. After thousands of pulses the span of all the measurements should remain <1000 ps.
Connect ch1 of FD board to ch1 of TDC board and ch3 of TDC board to ch1 with a different cable.
"""

def main (default_directory='.'):

    # Constants declaration
    FMC_TDC_ADDR = '1a39:0004/1a39:0004@000B:0000'
    FMC_TDC_BITSTREAM = '../firmwares/evas_tdc_v2_2.bit'#evas_tdc_irq8.bit'
    FMC_TDC_CHANNEL_NB = 5
    
    FMC_DELAY_ADDR = '1a39:0004/1a39:0004@0005:0000'
    FMC_DELAY_BITSTREAM = '../firmwares/fmc_delay_spec.bin'

    # SPEC object declaration
    spec = rr.Gennum()


    ###########################################################################
    # TDC
    ###########################################################################

    # Bind SPEC object to FMC TDC card
    print "-----------------------------------------------------------------"
    print "---------------------------- FMC TDC ---------------------------- "
    print "\n_______________________________Info______________________________\n"
    print "FMC TDC address to parse: %s"%(FMC_TDC_ADDR)
    for name, value in spec.parse_addr(FMC_TDC_ADDR).iteritems():
        print "%s:0x%04X"%(name, value)
    spec.bind(FMC_TDC_ADDR)

    # Load FMC TDC firmware
    print "\n_________________________Initialisations_________________________\n"
    print "Loading FMC TDC firmware...",
    spec.load_firmware(FMC_TDC_BITSTREAM)
    time.sleep(2)
    print "Firmware loaded!"

    # TDC object declaration
    tdc = fmc_tdc.CFMCTDC(spec)

    # TDC configuration
    print "\n__________________________Configuration__________________________\n"
    tdc.config_acam()
    tdc.set_irq_tstamp_thresh(0x100)
    tdc.set_irq_time_thresh(0xFF)
    time.sleep(1)

    # Enable the 5 TDC channels
    tdc.enable_channels()
    tdc.channel_term(1, 1)
    #for ch in range(1,FMC_TDC_CHANNEL_NB+1):
        #tdc.channel_term(ch, 1)

    # Check ACAM status
    print "\n___________________________ACAM reset____________________________\n"
    tdc.reset_acam()
    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "


    # Readback all ACAM configuration regs
    print "\n_________________Reading back ACAM configuration_________________\n"
    tdc.readback_acam_config()


    # Enable TDC core interrupts
    #print "\n____________________________IRQ mask_____________________________\n"
    #print('Set IRQ enable mask: %.4X')%tdc.set_irq_en_mask(0xC)


    # Enable timestamps aquisition
    print "\n_______________________Starting aquisition_______________________\n"
    tdc.start_acq()


    all_cable_delay_min = []
    all_cable_delay_max = []


    ###########################################################################
    # Fine Delay
    ###########################################################################

    print "\n-----------------------------------------------------------------"
    print "------------------------- FMC FINE DELAY ------------------------"
    # Bind SPEC object to FMC Fine Delay card
    print "Fine Delay address to parse %s"%(FMC_DELAY_ADDR)
    for name, value in spec.parse_addr(FMC_DELAY_ADDR).iteritems():
        print "%s:0x%04X"%(name, value)
    spec.bind(FMC_DELAY_ADDR)

    # Load FMC Fine Delay firmware
    print "\n\nLoading FMC Fine Delay firmware...",
    sys.stdout.flush()
    spec.load_firmware(FMC_DELAY_BITSTREAM)
    time.sleep(2)
    print "Firmware loaded!"

    # Fine Delay object declaration
    print "\n"
    fdelay = fdelay_lib.FineDelay(spec.get_fd())

    # Set UTC and Coarse time in the Fine Delay
    fdelay.set_time(0, 0)
    fd_time = fdelay_lib.fd_timestamp()
    fd_time = fdelay.get_time()
    print "\nFine Delay UTC time = %d, Coarse time = %d"%(fd_time.utc, fd_time.coarse)

    # Configure the Fine Delay as a pulse generator
    channel = 1 # must be 1, 2, 3 or 4
    enable = 1 # this one is obvious
    t_start_coarse = 0
    width = 2000000     # pulse width 2 us
    delta = 100000000   # a pulse every 100 us
    count = 64          # 64 pulses on each channel; 256 timestamps
    

    # several iterations of sending pulses and retrieving timestamps 
    for m in range(100000):

        print "\n\n>>Itteration:%d"%m

        ###########################################################################
        # Fine Delay
        ###########################################################################

        # Bind SPEC object to FMC Fine Delay card
        spec.bind(FMC_DELAY_ADDR)

        time.sleep(0.5) # somehow it's needed..otherwise after many iterations i get crushes!

        # Configure the Fine Delay as a pulse generator
        t_start_utc = fdelay.get_time().utc+1 # pulse(s) generation start time (-> 2 seconds in the future)
        fdelay.conf_pulsegen(channel, enable, t_start_utc, t_start_coarse, width, delta, count)
        print "\nFine Delay: %d pulses ready to be sent in 1 sec!"%count   



        ###########################################################################
        # TDC
        ###########################################################################

        # Bind SPEC object to FMC TDC card
        spec.bind(FMC_TDC_ADDR)

        print "\n_______________________TDC Accuracy testing______________________\n"

        #tdc.check_irq()
        time.sleep(5)
        print "IRQ iteration: %d // Overflows: %d // IRQ source: %d // Write pointer: %d\n"%(m, tdc.get_overflow_counter(), tdc.get_irq_src(), tdc.get_pointer()),


        timestamps, data = tdc.get_timestamps(0)

        r_edge_timestamps = []
        cable_delay_list = []
    
        for i in range(len(timestamps)):
             if ((timestamps[i][2] == 1)):# and (timestamps[i][1] == 0 or timestamps[i][1] == 2)):
                 r_edge_timestamps.append(timestamps[i][0])

        r_edge_timestamps.sort()

        for i in range(0,len(r_edge_timestamps),2):
            cable_delay = r_edge_timestamps[i+1] - r_edge_timestamps[i]
            cable_delay_list.append(cable_delay)


        current_max = max(cable_delay_list)
        current_min = min(cable_delay_list)
        span = current_max-current_min
        print "\nmax : %15.3f ps"%max(cable_delay_list)
        print "min : %15.3f ps"%min(cable_delay_list)
        print "span: %15.3f ps"%span

        if span > 800:
            print "Span messed up!"


        all_cable_delay_max.append(current_max)
        all_cable_delay_min.append(current_min)
        print "\nCurrent max: position %d,    %15.3f ps"%(all_cable_delay_max.index(max(all_cable_delay_max)), max(all_cable_delay_max))
        print "Current min: position %d,    %15.3f ps"%(all_cable_delay_min.index(min(all_cable_delay_min)),min(all_cable_delay_min))
        print "Current span:               %15.3f ps"%((max(all_cable_delay_max))-(min(all_cable_delay_min)))



    # out of the for loop!
    print "\n___________________________ACAM status___________________________\n"
    acam_status_test = tdc.read_acam_status()-0xC4000800
    if acam_status_test == 0:
        print "ACAM status OK!"
    else:
        print "/!\ACAM not OK../!\ "

    print "\n_________________Reading back ACAM configuration_________________\n"
    tdc.readback_acam_config()

    print "\n___________________________Statistics____________________________\n"
    print all_cable_delay_min
    print all_cable_delay_max
    print "#### Final span: %15.3f ps ####"%((max(all_cable_delay_max))-(min(all_cable_delay_min)))



    print "\n_______________________Stopping aquisition_______________________\n"
    tdc.stop_acq()

    print "\n-----------------------------------------------------------------\n\n\n"


if __name__ == '__main__' :
    main()
